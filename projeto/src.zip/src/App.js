import Card_body from "./components/Card_body/card_body";

function App() {
  return (
    <div>
      <Card_body/>
    </div>
  );
}

export default App;
